MikuMikuDance.exe�@Ver.9.32_English 64bitOS

Tool for choreography of 3D Models.

If cannot move, please install following runtime package.
  Microsoft Visual C++ 2008 Redistributable Package (x64)
    http://www.microsoft.com/en-us/download/details.aspx?id=15336
  Microsoft Visual C++ 2010 Redistributable Package (x64)
    http://www.microsoft.com/en-us/download/details.aspx?id=14632
  DirectX End-User Runtime
    http://www.microsoft.com/en-us/download/details.aspx?id=35

Operation tutorial 
   http://www.youtube.com/watch?v=Jx1qLlbtCQI
   http://www.youtube.com/watch?v=sCnX0EflenE


It is not necessary to apply me for the report and permission when the image or animation produced with this tool are opened to the public.

DISCLAIMER
 IN NO EVENT WILL THESE AUTHORS OF THIS SOFTWARE,3D MODELS,AND TUTORIAL BE LIABLE TO YOU FOR ANY AND ALL DAMAGES,GENERAL,SPECIAL,INCIDENTAL OR CONSEQUENTIAL,ARISING OUT OF THE USE OR INABILITY TO USE THE SOFTWARE,3D MODELS,AND RELATED FILES.
USE THEM AT YOUR OWN RISK.